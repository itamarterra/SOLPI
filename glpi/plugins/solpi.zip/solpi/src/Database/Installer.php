<?php

declare(strict_types=1);

namespace SOLPI\Database;

use Migration;

final class Installer
{
    /**
     * Executa a instalação do banco de dados.
     */
    public static function install(Migration $migration): bool
    {
        self::createSettingsTable($migration);
        self::createLogsTable($migration);
        self::createAlertsTable($migration);
        self::createWhatsappTable($migration);
        self::createAIHistoryTable($migration);

        return true;
    }

    private static function createSettingsTable(Migration $migration): void
    {
        if (!$migration->tableExists('glpi_plugin_solpi_settings')) {

            $migration->displayMessage('Criando tabela glpi_plugin_solpi_settings');

            $migration->execute("
                CREATE TABLE glpi_plugin_solpi_settings (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    value LONGTEXT NULL,
                    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY(name)
                ) ENGINE=InnoDB
                DEFAULT CHARSET=utf8mb4
                COLLATE=utf8mb4_unicode_ci;
            ");
        }
    }

    private static function createLogsTable(Migration $migration): void
    {
        if (!$migration->tableExists('glpi_plugin_solpi_logs')) {

            $migration->displayMessage('Criando tabela glpi_plugin_solpi_logs');

            $migration->execute("
                CREATE TABLE glpi_plugin_solpi_logs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    level VARCHAR(20) NOT NULL,
                    message LONGTEXT NOT NULL,
                    context LONGTEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX(level),
                    INDEX(created_at)
                ) ENGINE=InnoDB
                DEFAULT CHARSET=utf8mb4
                COLLATE=utf8mb4_unicode_ci;
            ");
        }
    }

    private static function createAlertsTable(Migration $migration): void
    {
        if (!$migration->tableExists('glpi_plugin_solpi_alerts')) {

            $migration->displayMessage('Criando tabela glpi_plugin_solpi_alerts');

            $migration->execute("
                CREATE TABLE glpi_plugin_solpi_alerts (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    host VARCHAR(255),
                    trigger_name VARCHAR(255),
                    severity VARCHAR(50),
                    status VARCHAR(30),
                    payload LONGTEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX(host),
                    INDEX(severity)
                ) ENGINE=InnoDB
                DEFAULT CHARSET=utf8mb4
                COLLATE=utf8mb4_unicode_ci;
            ");
        }
    }

    private static function createWhatsappTable(Migration $migration): void
    {
        // Implementaremos na Sprint Evolution API
    }

    private static function createAIHistoryTable(Migration $migration): void
    {
        // Implementaremos na Sprint IA
    }
}