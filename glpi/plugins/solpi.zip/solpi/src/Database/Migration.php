<?php

declare(strict_types=1);

namespace SOLPI\Database;

use Migration;

final class MigrationManager
{
    private Migration $migration;

    public function __construct(Migration $migration)
    {
        $this->migration = $migration;
    }

    public function getMigration(): Migration
    {
        return $this->migration;
    }

    public function execute(callable $callback): void
    {
        $callback($this->migration);
    }
}