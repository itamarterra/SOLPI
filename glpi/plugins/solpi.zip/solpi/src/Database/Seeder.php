<?php

declare(strict_types=1);

namespace SOLPI\Database;

final class Seeder
{
    public static function run(): void
    {
        self::seedConfig();
        self::seedDashboard();
        self::seedWebhook();
    }

    private static function seedConfig(): void
    {
        // implementação futura
    }

    private static function seedDashboard(): void
    {
        // implementação futura
    }

    private static function seedWebhook(): void
    {
        // implementação futura
    }
}