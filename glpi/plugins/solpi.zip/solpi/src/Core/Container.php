<?php

declare(strict_types=1);

namespace SOLPI\Core;

use Closure;
use RuntimeException;

/**
 * Container de Injeção de Dependências.
 */
final class Container
{
    /**
     * @var array<string, Closure|object>
     */
    private array $services = [];

    public function bind(string $id, Closure $resolver): void
    {
        $this->services[$id] = $resolver;
    }

    public function singleton(string $id, Closure $resolver): void
    {
        $instance = null;

        $this->services[$id] = function () use ($resolver, &$instance) {
            if ($instance === null) {
                $instance = $resolver();
            }

            return $instance;
        };
    }

    public function instance(string $id, object $object): void
    {
        $this->services[$id] = $object;
    }

    public function get(string $id): mixed
    {
        if (!isset($this->services[$id])) {
            throw new RuntimeException("Serviço '{$id}' não registrado.");
        }

        $service = $this->services[$id];

        return $service instanceof Closure
            ? $service()
            : $service;
    }

    public function has(string $id): bool
    {
        return isset($this->services[$id]);
    }
}