<?php

declare(strict_types=1);

namespace SOLPI\Core;

use DBmysql;
use RuntimeException;

/**
 * Gerenciador de conexão com o banco do GLPI.
 */
final class Database
{
    private static ?DBmysql $connection = null;

    public static function getConnection(): DBmysql
    {
        if (self::$connection instanceof DBmysql) {
            return self::$connection;
        }

        global $DB;

        if (!$DB instanceof DBmysql) {
            throw new RuntimeException(
                'Conexão com o banco de dados do GLPI não encontrada.'
            );
        }

        self::$connection = $DB;

        return self::$connection;
    }
}