<?php

declare(strict_types=1);

namespace SOLPI\Core;

use DateTimeImmutable;

final class Logger
{
    private static string $directory = '';

    private function __construct()
    {
    }

    public static function initialize(string $directory): void
    {
        self::$directory = rtrim($directory, DIRECTORY_SEPARATOR);

        if (!is_dir(self::$directory)) {
            mkdir(self::$directory, 0755, true);
        }
    }

    public static function info(string $message): void
    {
        self::write('INFO', $message);
    }

    public static function warning(string $message): void
    {
        self::write('WARNING', $message);
    }

    public static function error(string $message): void
    {
        self::write('ERROR', $message);
    }

    private static function write(string $level, string $message): void
    {
        if (self::$directory === '') {
            return;
        }

        $date = new DateTimeImmutable();

        $line = sprintf(
            "[%s] [%s] %s%s",
            $date->format('Y-m-d H:i:s'),
            $level,
            $message,
            PHP_EOL
        );

        file_put_contents(
            self::$directory . DIRECTORY_SEPARATOR . 'solpi.log',
            $line,
            FILE_APPEND | LOCK_EX
        );
    }
}