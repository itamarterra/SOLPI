﻿<?php

declare(strict_types=1);

namespace SOLPI\Core;

final class Environment
{
    public static function isProduction(): bool
    {
        return true;
    }

    public static function isDebug(): bool
    {
        return false;
    }
}
