<?php

declare(strict_types=1);

namespace SOLPI\Core;

final class Version
{
    public const NAME = 'SOLPI Professional';

    public const PLUGIN = 'solpi';

    public const VERSION = '2.0.0';

    public const AUTHOR = 'Itamar Terra';

    public const LICENSE = 'MIT';

    public const GLPI_MIN = '11.0.0';

    public const GLPI_MAX = '11.9.99';

    private function __construct()
    {
    }

    public static function info(): array
    {
        return [
            'name' => self::NAME,
            'version' => self::VERSION,
            'author' => self::AUTHOR,
            'license' => self::LICENSE,
            'requirements' => [
                'glpi' => [
                    'min' => self::GLPI_MIN,
                    'max' => self::GLPI_MAX
                ]
            ]
        ];
    }
}