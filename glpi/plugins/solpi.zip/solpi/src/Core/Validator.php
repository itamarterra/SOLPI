<?php

declare(strict_types=1);

namespace SOLPI\Core;

/**
 * Classe responsável por validações.
 */
final class Validator
{
    private array $errors = [];

    public function required(string $field, mixed $value): self
    {
        if ($value === null || $value === '') {
            $this->errors[$field][] = 'Campo obrigatório.';
        }

        return $this;
    }

    public function email(string $field, string $value): self
    {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field][] = 'E-mail inválido.';
        }

        return $this;
    }

    public function min(string $field, string $value, int $length): self
    {
        if (mb_strlen($value) < $length) {
            $this->errors[$field][] =
                "Mínimo de {$length} caracteres.";
        }

        return $this;
    }

    public function max(string $field, string $value, int $length): self
    {
        if (mb_strlen($value) > $length) {
            $this->errors[$field][] =
                "Máximo de {$length} caracteres.";
        }

        return $this;
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function fails(): bool
    {
        return !$this->passes();
    }
}