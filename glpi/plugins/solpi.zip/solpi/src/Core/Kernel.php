<?php

declare(strict_types=1);

namespace SOLPI\Core;

/**
 * Kernel principal do SOLPI.
 * Responsável por inicializar todos os módulos do sistema.
 */
final class Kernel
{
    private static ?Kernel $instance = null;

    private bool $booted = false;

    private function __construct()
    {
    }

    public static function getInstance(): Kernel
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        $this->booted = true;
    }

    public function isBooted(): bool
    {
        return $this->booted;
    }
}