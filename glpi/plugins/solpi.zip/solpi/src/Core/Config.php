<?php

declare(strict_types=1);

namespace SOLPI\Core;

final class Config
{
    private static array $items = [];

    private function __construct()
    {
    }

    public static function set(string $key, mixed $value): void
    {
        self::$items[$key] = $value;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return self::$items[$key] ?? $default;
    }

    public static function has(string $key): bool
    {
        return array_key_exists($key, self::$items);
    }

    public static function all(): array
    {
        return self::$items;
    }

    public static function clear(): void
    {
        self::$items = [];
    }
}