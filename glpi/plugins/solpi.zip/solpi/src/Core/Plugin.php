<?php

declare(strict_types=1);

namespace SOLPI\Core;

final class Plugin
{
    private static bool $booted = false;

    private function __construct()
    {
    }

    public static function boot(): void
    {
        if (self::$booted) {
            return;
        }

        self::$booted = true;

        Logger::initialize(
            dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'logs'
        );
    }

    public static function isBooted(): bool
    {
        return self::$booted;
    }

    public static function version(): array
    {
        return Version::info();
    }
}