<?php

declare(strict_types=1);

namespace SOLPI\Core;

/**
 * Classe responsável pelas respostas HTTP.
 */
final class Response
{
    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(
            $data,
            JSON_PRETTY_PRINT
            | JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        );

        exit;
    }

    public static function redirect(string $url): never
    {
        header("Location: {$url}");
        exit;
    }

    public static function success(string $message): never
    {
        self::json([
            'success' => true,
            'message' => $message
        ]);
    }

    public static function error(string $message, int $status = 500): never
    {
        self::json([
            'success' => false,
            'message' => $message
        ], $status);
    }
}