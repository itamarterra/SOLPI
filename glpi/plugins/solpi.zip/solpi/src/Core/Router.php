<?php

declare(strict_types=1);

namespace SOLPI\Core;

/**
 * Roteador interno do SOLPI.
 */
final class Router
{
    /**
     * @var array<string, callable>
     */
    private array $getRoutes = [];

    /**
     * @var array<string, callable>
     */
    private array $postRoutes = [];

    public function get(string $route, callable $action): void
    {
        $this->getRoutes[$route] = $action;
    }

    public function post(string $route, callable $action): void
    {
        $this->postRoutes[$route] = $action;
    }

    public function dispatch(string $method, string $route): mixed
    {
        $routes = strtoupper($method) === 'POST'
            ? $this->postRoutes
            : $this->getRoutes;

        if (!isset($routes[$route])) {
            throw new \RuntimeException(
                "Rota '{$route}' não encontrada."
            );
        }

        return call_user_func($routes[$route]);
    }

    public function getRoutes(): array
    {
        return [
            'GET' => $this->getRoutes,
            'POST' => $this->postRoutes
        ];
    }
}